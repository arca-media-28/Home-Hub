# Tachboard logo assets

Mosaic "T" built from mixed-size dashboard tiles, set in a navy field with a white
keyline. Derived from the F.I. parent mark (red accent, thick white keyline).

## Palette

| Role | Hex | Used for |
|---|---|---|
| Field navy | `#16244A` | Container fill |
| Keyline | `#FFFFFF` | Container stroke |
| Tile light | `#E8ECF5` | Top-left and top-centre tiles |
| Tile mid | `#CDD6E8` | Upper stem tile |
| Tile deep | `#8FA1C8` | Lower stem tile |
| Accent red | `#D93A3A` | Top-right status tile |

Sample the exact accent red from your app CSS before shipping — it should match the
play button and gauge arcs, not sit a shade off.

## Files

**Vector**
- `tachboard-mark.svg` — primary mark, 512 canvas, use everywhere
- `tachboard-mark-status.svg` — identical, but the red tile carries `id="status-tile"`
  so you can drive its fill from service health (green `#22C55E` when all up)
- `tachboard-mark-mono.svg` — single colour, fills with `currentColor`
- `tachboard-favicon.svg` — widened gutters, thinner keyline, for 32–64px
- `tachboard-favicon-tiny.svg` — simplified 3+1 tile glyph, for 16–24px
- `tachboard-lockup.svg` — horizontal mark + wordmark

**Raster** (`png/`)
- Mark at 1024, 512, 256, 128, 64
- Favicon at 64, 32, 16 and tiny at 48, 32, 24, 16
- Mono in white at 512
- Lockup at 452 and 1356 wide

**`favicon.ico`** — 16 / 32 / 48 bundled

## Which file at which size

| Size | File |
|---|---|
| 64px and up | `tachboard-mark.svg` |
| 32–48px | `tachboard-favicon.svg` |
| 16–24px | `tachboard-favicon-tiny.svg` |

The gutters between tiles are the first thing to fail when scaling down. Each
variant widens them and simplifies the stem to compensate — don't just scale the
primary mark to 16px.

## Geometry

Everything sits on a 512 grid. The mark occupies 336×336 centred at 88,88, leaving
22% padding to the container edge. Tiles are 104 wide with 12px gutters; corner
radius is 20 on tiles, 108 on the container. Keep these as ratios if you rebuild at
another size.

## Wordmark caveat

The lockup uses a font stack (Inter, then system sans). Anyone without Inter gets a
substitute and the spacing shifts. Before this goes anywhere public, swap in whatever
font your app header actually uses and convert the text to outlines.

## Clear space

Leave at least one tile width (104 units, or 20% of the mark height) clear on all
sides. In the app header that's roughly 8px at a 40px logo.
